import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import './profile.css';
import Pronav from './Pronav';
import { ProfileContext } from './ProfileContext';

function Profile() {
  const [username, setUsername] = useState('');
  const navigate = useNavigate();
  const { profileData } = useContext(ProfileContext);

  // Assuming token is part of profileData or needs to be retrieved
  const token = profileData?.token;

  useEffect(() => {
    const fetchUsername = async () => {
      if (!token) {
        console.error('Token is missing');
        return;
      }

      try {
        const response = await fetch('http://127.0.0.1:8000/api/user/', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          }
        });

        if (!response.ok) {
          throw new Error('Failed to fetch username');
        }

        const data = await response.json();
        setUsername(data.username);
      } catch (error) {
        console.error('Error fetching username:', error);
      }
    };

    fetchUsername();

    // Navigate to /personal_info when the component mounts
    navigate('/personal_info');
  }, [navigate, token]);

  return (
    <div className='profile'>
      <div className="welcome">
        {username ? (
          <h2>Welcome, {username}</h2>
        ) : (
          <p>Loading...</p>
        )}
      </div>
      <Pronav />
    </div>
  );
}

export default Profile;
