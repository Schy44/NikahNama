import React, { useState, useEffect } from 'react';
import './notif.css';
import Pronav from './Pronav';

function Notification() {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsername = async () => {
      try {
        const token = localStorage.getItem('authToken'); // Get the token from localStorage
        if (!token) {
          throw new Error('Authentication token is missing');
        }

        const response = await fetch('http://127.0.0.1:8000/api/user/', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`, // Include token in the headers
          }
        });

        if (!response.ok) {
          const errorDetails = await response.text();
          console.error(`Error fetching username: ${response.status} - ${errorDetails}`);
          throw new Error('Failed to fetch username');
        }

        const data = await response.json();
        setUsername(data.username);
      } catch (error) {
        console.error('Error fetching username:', error.message);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUsername();
  }, []);

  return (
    <div className='profile'>
      <div className="welcome">
        {loading ? (
          <p>Loading...</p>
        ) : error ? (
          <p>Error: {error}</p>
        ) : (
          <h2>Welcome, {username}</h2>
        )}
      </div>
      <Pronav />
      <div className="notification">
        <div className="notification-item">
          <h2>Notifications</h2>
          <div className="notification-content">
            <p>{username ? `${username} wants to see your profile picture?` : 'Loading user...'}</p>
            <button>Accept</button>
            <button>Decline</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Notification;
