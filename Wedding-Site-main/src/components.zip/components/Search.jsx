import React, { useState, useEffect } from 'react';
import './profile.css';
import Pronav from './Pronav';

export default function Search() {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsername = async () => {
      try {
        const token = localStorage.getItem('authToken'); // Get the token from localStorage
        if (!token) {
          throw new Error('Authentication token is missing');
        }

        const response = await fetch('http://127.0.0.1:8000/api/user/', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`, // Include token in the headers if required
          }
        });

        if (!response.ok) {
          const errorDetails = await response.text();
          console.error(`Error fetching username: ${response.status} - ${errorDetails}`);
          throw new Error('Failed to fetch username');
        }

        const data = await response.json();
        setUsername(data.username);
      } catch (error) {
        console.error('Error fetching username:', error.message);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    // Fetch username from localStorage if available
    const storedUsername = localStorage.getItem('username');
    if (storedUsername) {
      setUsername(storedUsername);
      setLoading(false);
    } else {
      fetchUsername();
    }
  }, []);

  return (
    <div className='profile'>
      <div className="welcome">
        {loading ? (
          <p>Loading...</p>
        ) : error ? (
          <p>Error: {error}</p>
        ) : (
          <h2>Welcome, {username}</h2>
        )}
      </div>
      <Pronav />
      <div>Search</div>
    </div>
  );
}
