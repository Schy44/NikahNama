import React, { useState, useEffect, useContext } from 'react';
import './userprofile.css';
import Pronav from './Pronav';
import { ProfileContext } from './ProfileContext';

function UserProfile() {
  const [username, setUsername] = useState('');
  const { profileData } = useContext(ProfileContext);

  useEffect(() => {
    const token = localStorage.getItem('authToken');

    if (token) {
      const storedUsername = localStorage.getItem('username');
      if (storedUsername) {
        setUsername(storedUsername);
      }

      const fetchProfileData = async () => {
        try {
          const response = await fetch('http://127.0.0.1:8000/api/user/', {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
          });

          if (!response.ok) {
            const errorDetails = await response.text();
            console.error(`Error fetching profile data: ${response.status} - ${errorDetails}`);
            throw new Error('Failed to fetch profile data');
          }

          const data = await response.json();
          setUsername(data.username || storedUsername);
        } catch (error) {
          console.error('Error fetching profile data:', error.message);
        }
      };

      fetchProfileData();
    } else {
      // If no token is found, clear the username
      setUsername('Guest');
    }
  }, []);


  return (
    <div className='profile'>
      <div className="welcome">
        {username ? <h2>Welcome, {username}</h2> : <p>Loading...</p>}
      </div>
      <Pronav />
      <div className="user-profile">
        <div className="profile-item">
          <div className="biodata-container">
            <div className="biodata-header">
              <h2>Matrimonial Biodata</h2>
            </div>

            <div className="photo-section">
              <img
                src={profileData?.profilePicture || 'default-profile-picture.jpg'}
                alt="Profile Picture"
              />
            </div>

            <div className="section">
              <h3>Basic Information</h3>
              <div className="info-row">
                <span>Full Name:</span> <span className="info-value">{profileData?.fullName || ''}</span>
              </div>
              <div className="info-row">
                <span>Gender:</span> <span className="info-value">{profileData?.gender || ''}</span>
              </div>
              <div className="info-row">
                <span>Date of Birth:</span> <span className="info-value">{profileData?.dob || ''}</span>
              </div>
              <div className="info-row">
                <span>Location:</span> <span className="info-value">{profileData?.location || ''}</span>
              </div>
            </div>

            <div className="section">
              <h3>Personal Information</h3>
              <div className="info-row">
                <span>Height:</span> <span className="info-value">{profileData?.height || ''}</span>
              </div>
              <div className="info-row">
                <span>Weight:</span> <span className="info-value">{profileData?.weight || ''}</span>
              </div>
              <div className="info-row">
                <span>Body Type:</span> <span className="info-value">{profileData?.bodyType || ''}</span>
              </div>
              <div className="info-row">
                <span>Ethnicity:</span> <span className="info-value">{profileData?.ethnicity || ''}</span>
              </div>
              <div className="info-row">
                <span>Religion:</span> <span className="info-value">{profileData?.religion || ''}</span>
              </div>
              <div className="info-row">
                <span>Languages Spoken:</span> <span className="info-value">{profileData?.languages || ''}</span>
              </div>
            </div>

            <div className="section">
              <h3>Education & Profession</h3>
              <div className="info-row">
                <span>Highest Education:</span> <span className="info-value">{profileData?.education || ''}</span>
              </div>
              <div className="info-row">
                <span>Institution:</span> <span className="info-value">{profileData?.institution || ''}</span>
              </div>
              <div className="info-row">
                <span>Occupation:</span> <span className="info-value">{profileData?.occupation || ''}</span>
              </div>
              <div className="info-row">
                <span>Company:</span> <span className="info-value">{profileData?.company || ''}</span>
              </div>
            </div>

            <div className="section">
              <h3>Family Background</h3>
              <div className="info-row">
                <span>Family Type:</span> <span className="info-value">{profileData?.familyType || ''}</span>
              </div>
              <div className="info-row">
                <span>Father's Occupation:</span> <span className="info-value">{profileData?.fatherOccupation || ''}</span>
              </div>
              <div className="info-row">
                <span>Mother's Occupation:</span> <span className="info-value">{profileData?.motherOccupation || ''}</span>
              </div>
              <div className="info-row">
                <span>Siblings:</span> <span className="info-value">{profileData?.siblings || ''}</span>
              </div>
            </div>

            <div className="section">
              <h3>Lifestyle & Interests</h3>
              <div className="info-row">
                <span>Dietary Preferences:</span> <span className="info-value">{profileData?.diet || ''}</span>
              </div>
              <div className="info-row">
                <span>Smoking Habits:</span> <span className="info-value">{profileData?.smoking || ''}</span>
              </div>
              <div className="info-row">
                <span>Drinking Habits:</span> <span className="info-value">{profileData?.drinking || ''}</span>
              </div>
              <div className="info-row">
                <span>Hobbies:</span> <span className="info-value">{profileData?.hobbies || ''}</span>
              </div>
            </div>

            <div className="section">
              <h3>Partner Preferences</h3>
              <div className="info-row">
                <span>Age Range:</span> <span className="info-value">{profileData?.partnerAgeRange || ''}</span>
              </div>
              <div className="info-row">
                <span>Height Preference:</span> <span className="info-value">{profileData?.partnerHeight || ''}</span>
              </div>
              <div className="info-row">
                <span>Religion:</span> <span className="info-value">{profileData?.partnerReligion || ''}</span>
              </div>
              <div className="info-row">
                <span>Education:</span> <span className="info-value">{profileData?.partnerEducation || ''}</span>
              </div>
              <div className="info-row">
                <span>Occupation:</span> <span className="info-value">{profileData?.partnerOccupation || ''}</span>
              </div>
              <div className="info-row">
                <span>Location Preference:</span> <span className="info-value">{profileData?.partnerLocation || ''}</span>
              </div>
            </div>

            <div className="section">
              <h3>Contact Information</h3>
              <div className="info-row">
                <span>Email:</span> <span className="info-value">{profileData?.email || ''}</span>
              </div>
              <div className="info-row">
                <span>Phone:</span> <span className="info-value">{profileData?.phone || ''}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserProfile;
